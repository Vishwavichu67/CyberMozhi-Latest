"use client";

import { useCallback, useState } from 'react';
import { ChatHistorySidebar } from '@/components/chatbot/ChatHistorySidebar';
import { ChatInterface } from '@/components/chatbot/ChatInterface';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function ChatPage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  const [chatSessionId, setChatSessionId] = useState<string | null>(null);
  const [isSidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    if (!loading && !user) router.push('/login');
  }, [user, loading, router]);

  const handleSelectChatSession = useCallback((sessionId: string | null) => {
    setChatSessionId(sessionId);
    setSidebarOpen(false); // close on mobile after selecting
  }, []);

  const handleNewChat = useCallback(() => {
    setChatSessionId(null);
    setSidebarOpen(false);
  }, []);

  if (loading || !user) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="flex flex-1 w-full overflow-hidden relative">

      {/* ── Sidebar — inline, not a Sheet/portal ───────────────────────────
          Uses translate-x to slide in/out on mobile.
          On desktop (md+) it's always visible as a fixed-width column.
          No overflow:hidden — dropdown menus render freely.
      ──────────────────────────────────────────────────────────────────── */}

      {/* Mobile overlay backdrop */}
      {isSidebarOpen && (
        <div
          className="fixed inset-0 z-20 bg-black/40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar panel */}
      <div className={cn(
        // Base: fixed on mobile, relative on desktop
        'fixed md:relative z-30 md:z-auto',
        'top-0 left-0 h-full w-72 md:w-64',
        'bg-background border-r border-border/40',
        // Slide transition on mobile
        'transition-transform duration-200 ease-in-out md:translate-x-0',
        isSidebarOpen ? 'translate-x-0' : '-translate-x-full',
        // Always show on desktop
        'md:flex md:flex-col md:shrink-0',
      )}>
        <ChatHistorySidebar
          currentChatSessionId={chatSessionId}
          onSelectChatSession={handleSelectChatSession}
          onNewChat={handleNewChat}
        />
      </div>

      {/* ── Main chat area ─────────────────────────────────────────────── */}
      <div className="flex-1 flex flex-col overflow-hidden min-w-0">
        <ChatInterface
          chatSessionId={chatSessionId}
          setChatSessionId={setChatSessionId}
          onToggleSidebar={() => setSidebarOpen(prev => !prev)}
          onNewChat={handleNewChat}
        />
      </div>
    </div>
  );
}